/**
 * @file Lwp3Gt4.hpp
 * @brief v5.3 "Clean API" HAL for LEGO Porsche GT4.
 * * Features:
 * - High-level public interface for light control (Front/Rear abstraction).
 * - Enforced calibration safety gate.
 * - Lock-free telemetry and command latches.
 */

#pragma once
#include <simpleble/SimpleBLE.h>

#include <atomic>
#include <condition_variable>
#include <cstdint>
#include <functional>
#include <mutex>
#include <string_view>
#include <thread>
#include <vector>

namespace LWP3 {

using TimestampNs = uint64_t;

struct alignas(16) Telemetry {
    int32_t steer_pos = 0;
    TimestampNs timestamp_ns = 0;
    uint8_t battery_level = 100;
    bool link_healthy = false;
};

struct Command {
    int32_t steer = 0;
    int32_t throttle = 0;
};

struct TxEvent {
    int32_t steer_cmd;
    TimestampNs timestamp_ns;
};

struct LatencyStats {
    float mean_ms;
    float p50_ms;
    float p99_ms;
};

struct HalConfig {
    uint32_t tx_rate_limit_ms = 15;
    uint32_t watchdog_timeout_ms = 200;
    uint32_t keepalive_ms = 250;
    int32_t max_steer_delta_per_tx = 0;
};

enum class HalStatus { OK, UNCALIBRATED, DISCONNECTED, TIMEOUT, DEGRADED };

class PorscheGt4 {
   public:
    PorscheGt4();
    ~PorscheGt4();

    /**
     * @brief Persistent Connection Loop.
     * * Blocks until the Hub is found and GATT services are mapped.
     * @param address The Bluetooth MAC of the Hub.
     * @return true if established.
     */
    bool connect(std::string_view address);

    /** @brief Graceful shutdown of motors and BLE agent. */
    void disconnect();

    /**
     * @brief Essential Physical Calibration.
     * * Sweeps to physical stops to find 'Zero' and 'Soft Margins'.
     * * MUST be called before sendCommand() will accept inputs.
     * @return true if calibration succeeded.
     */
    bool autoCalibrate();

    /** @brief Sets Front Headlight brightness (0-100). */
    void setFrontLights(uint8_t brightness) noexcept;

    /** @brief Sets Rear Brake/Tail light brightness (0-100). */
    void setRearLights(uint8_t brightness) noexcept;

    /** @brief Check if the HAL is ready for autonomous commands. */
    bool isCalibrated() const noexcept {
        return _isCalibrated.load();
    }

    /** @brief Updates operational parameters (Rate limits, Watchdogs). */
    void configure(const HalConfig& cfg);

    /** @brief Atomic Command Latch (Latest-Wins). Rejects inputs if not calibrated. */
    void sendCommand(const Command& cmd) noexcept;

    /** @brief Returns the last received hardware state (Lock-free). */
    Telemetry getLatestTelemetry() const noexcept;

    /** @brief Real-time Profiler (Mean, P50, P99). */
    LatencyStats getLatencyStats();

    /** @brief Aggregated health status of the HAL. */
    HalStatus getStatus() const noexcept;

    /** @brief Async callback for telemetry-driven logic. */
    std::function<void(const Telemetry&)> onTelemetry;

   private:
    /** @brief The SimpleBLE peripheral handle. Marked mutable to allow const status checks. */
    mutable SimpleBLE::Peripheral porsche;
    HalConfig _config;

    // Execution Logic
    std::jthread _txThread;
    std::atomic<bool> _running{false};
    std::atomic<bool> _isHardwareReady{false};
    std::atomic<bool> _isCalibrated{false};
    std::condition_variable _txCv;
    std::mutex _txMtx;

    // Latches
    std::atomic<Command> _latestCmd{Command{0, 0}};
    std::atomic<bool> _hasNewCmd{false};
    std::atomic<Telemetry> _telemetryLatch{Telemetry{}};
    std::atomic<HalStatus> _status{HalStatus::DISCONNECTED};

    // Internal States
    std::atomic<int32_t> _rawSteerPos{0};
    std::atomic<bool> _calibrating{false};
    std::atomic<bool> _telemetryActive{false};

    // Profiling
    std::mutex _statsMtx;
    std::vector<TxEvent> _pendingTx;
    std::vector<float> _latencySamples;
    const size_t MAX_SAMPLES = 50;

    std::atomic<TimestampNs> _lastCmdTime{0};
    int32_t _lastSentSteer = 0;
    TimestampNs _lastTxTimestamp = 0;

    // --- Private Internal Methods ---

    /** @brief Generic LWP3 light control implementation. */
    void setLights(uint8_t port, uint8_t brightness) noexcept;

    /** @brief Main TX thread logic. */
    void txLoop(std::stop_token st);

    /** @brief LWP3 protocol handshake. */
    void setupHandshake();

    /** @brief Telemetry ingestion and latency matching. */
    void updateTelemetry(int32_t pos, uint8_t batt);

    /** @brief Monotonic nanosecond clock. */
    TimestampNs getNowNs() const;

    // --- Protocol Builders ---
    SimpleBLE::ByteArray buildSteerCmd(int32_t absolute_angle, uint8_t speed = 50);
    SimpleBLE::ByteArray buildDriveCmd(uint8_t port, int8_t speed);
    int32_t sweep_to_limit(int8_t speed, std::string_view side);
    void sendReliable(const SimpleBLE::ByteArray& data);
    void waitForMovement(int32_t target_abs, int timeout_ms = 2000);

    int32_t hardwareCenter = 0;
    int32_t minRelative = -65;
    int32_t maxRelative = 65;
    std::atomic<uint8_t> _virtualDrivePort{0xFF};
};

}  // namespace LWP3
