/**
 * @file Lwp3Constants.hpp
 * @author lsuciu
 * @brief v5.2 Refined LWP3 protocol constants for LEGO Porsche GT4.
 */

#pragma once
#include <cstdint>

namespace LWP3 {

// --- Bluetooth Hardware Identifiers ---
static constexpr const char* SERVICE_UUID = "00001623-1212-efde-1623-785feabcd123";
static constexpr const char* CHAR_UUID = "00001624-1212-efde-1623-785feabcd123";

// --- Porsche GT4 Physical Port Mapping ---
static constexpr uint8_t PORT_STEER = 0x34;         // Technic Large Angular Motor
static constexpr uint8_t PORT_DRIVE_L = 0x32;       // Technic XL Motor (Left)
static constexpr uint8_t PORT_DRIVE_R = 0x33;       // Technic XL Motor (Right)
static constexpr uint8_t PORT_LIGHTS_FRONT = 0x00;  // Port A
static constexpr uint8_t PORT_LIGHTS_REAR = 0x01;   // Port B (Example)

/** @brief Message Type identifiers for the LWP3 header. */
enum class MessageType : uint8_t {
    HUB_PROPERTIES = 0x01,
    HUB_ACTIONS = 0x02,
    HUB_ATTACHED_IO = 0x04,
    GENERIC_ERROR_MESSAGES = 0x05,
    PORT_INPUT_FORMAT_SETUP = 0x41,
    PORT_VALUE_SINGLE = 0x45,
    VIRTUAL_PORT_SETUP = 0x61,
    PORT_OUTPUT_COMMAND = 0x81
};

/** @brief Execution flags for Port Output Commands. */
enum class ExecutionFlags : uint8_t {
    IMMEDIATE = 0x11,  // Execute immediately, no buffering (Standard for ADAS)
    BUFFERED = 0x00    // Wait for previous command to finish
};

/** @brief Sub-commands for port output (Mode 0x81). */
enum class PortOutputSubCommand : uint8_t {
    START_SPEED = 0x01,            // Open-loop speed control
    GOTO_ABS_POS = 0x0D,           // Closed-loop servo position
    WRITE_DIRECT_MODE_DATA = 0x51  // High-frequency raw data write
};

/** @brief Behavior of the motor after a command completes. */
enum class MotorEndState : uint8_t {
    FLOAT = 0x00,  // Passive coast
    BRAKE = 0x7F,  // Active short-circuit brake
    HOLD = 0x7E    // Servo hold (Maintain position)
};

/** @brief Mode settings for steering telemetry. */
static constexpr uint8_t STEER_MODE_ABS_POS = 0x02;

/** @brief Protocol padding and limits. */
static constexpr uint8_t HUB_ID = 0x00;
static constexpr uint8_t MAX_MOTOR_POWER = 0x64;  // 100%
static constexpr uint8_t CMD_END_PACKET = 0x03;   // LWP3 terminator
static constexpr uint8_t NOTIFICATIONS_ON = 0x01;

}  // namespace LWP3
