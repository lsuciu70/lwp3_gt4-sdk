/**
 * @file hello_gt4.cpp
 * @brief v5.3 "Slalom with Visual Feedback"
 * * Added: Startup light reset, 'Get Ready' flash, Brake light logic, and 'Done' signal.
 */

#include <cmath>
#include <iostream>
#include <thread>

#include "Lwp3Gt4.hpp"

using namespace std::chrono_literals;

/**
 * @brief Utility to hold a command for a specific duration.
 */
void holdCommand(LWP3::PorscheGt4& car, int8_t speed, int32_t steer, int ms) {
    auto end = std::chrono::steady_clock::now() + std::chrono::milliseconds(ms);
    while (std::chrono::steady_clock::now() < end) {
        car.sendCommand({steer, speed});
        std::this_thread::sleep_for(20ms);
    }
}

/**
 * @brief Utility to flash front lights for status signals.
 */
void flashFrontLights(LWP3::PorscheGt4& car, int count, int delay_ms = 200) {
    for (int i = 0; i < count; ++i) {
        car.setFrontLights(100);
        std::this_thread::sleep_for(std::chrono::milliseconds(delay_ms));
        car.setFrontLights(0);
        if (i < count - 1) {
            std::this_thread::sleep_for(std::chrono::milliseconds(delay_ms));
        }
    }
}

int main(int argc, char** argv) {
    std::string mac = (argc > 1) ? argv[1] : "28:3C:90:9C:82:14";
    LWP3::PorscheGt4 car;

    if (!car.connect(mac)) return 1;

    // 1. START WITH LIGHTS OFF
    car.setFrontLights(0);
    car.setRearLights(0);

    car.autoCalibrate();

    // 2. GET READY SIGNAL (Flash twice)
    std::cout << "Calibration Complete. Get Ready...\n";
    flashFrontLights(car, 2);
    std::this_thread::sleep_for(500ms);

    std::cout << "Accelerating...\n";
    for (int s = 0; s <= 40; s += 2) holdCommand(car, s, 0, 50);

    std::cout << "Starting Smooth Slalom...\n";
    for (int i = 0; i < 300; ++i) {
        float t = i * 0.02f;

        float envelope = 1.0f;
        if (i > 250) envelope = 1.0f - ((i - 250) / 50.0f);

        int32_t angle = static_cast<int32_t>(envelope * 50.0f * std::sin(t * 3.5f));
        car.sendCommand({angle, 40});
        std::this_thread::sleep_for(20ms);
    }

    // 3. BRAKING AT THE END (Rear lights ON)
    std::cout << "Decelerating (Braking)...\n";
    car.setRearLights(100);  // Activate brake lights
    for (int s = 40; s >= 0; s -= 2) {
        holdCommand(car, s, 0, 50);
    }

    // Ensure car is fully stopped and turn off brake lights
    holdCommand(car, 0, 0, 500);
    car.setRearLights(0);

    // 4. WE'RE DONE SIGNAL (Flash once)
    std::cout << "Slalom Complete. We're done.\n";
    flashFrontLights(car, 1, 500);

    car.disconnect();
    return 0;
}
