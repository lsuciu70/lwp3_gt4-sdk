/**
 * @file Lwp3Gt4.cpp
 * @author lsuciu
 * @brief v5.2 Core HAL Implementation for LEGO Porsche GT4.
 * * DESIGN PRINCIPLES ENFORCED:
 * 1. Deterministic Timing: All events use CLOCK_MONOTONIC_RAW.
 * 2. State Safety: sendCommand() is gated until autoCalibrate() completes.
 * 3. Lock-Free Flow: Atomic latches for latest command and telemetry.
 * 4. Transparent Hardware: No internal PID or smoothing; raw pipe only.
 */

#include "Lwp3Gt4.hpp"

#include <cstring>

#include "Lwp3Constants.hpp"

using namespace std::chrono_literals;

namespace LWP3 {

PorscheGt4::PorscheGt4() {}

PorscheGt4::~PorscheGt4() {
    disconnect();
}

/**
 * @brief Internal clock helper for nanosecond precision.
 */
TimestampNs PorscheGt4::getNowNs() const {
    timespec ts;
    clock_gettime(CLOCK_MONOTONIC_RAW, &ts);
    return static_cast<TimestampNs>(ts.tv_sec) * 1'000'000'000ULL + ts.tv_nsec;
}

void PorscheGt4::configure(const HalConfig& cfg) {
    _config = cfg;
}

/**
 * @brief Persistent Discovery and Connection Loop.
 * Blocks until the Hub is found and GATT services are mapped.
 */
bool PorscheGt4::connect(std::string_view address) {
    while (true) {
        auto adapters = SimpleBLE::Adapter::get_adapters();
        if (adapters.empty()) {
            std::this_thread::sleep_for(1s);
            continue;
        }

        auto adapter = adapters[0];
        std::cout << "\r[HAL] Waiting for Porsche (" << address << ")... " << std::flush;

        adapter.scan_for(1000);
        auto results = adapter.scan_get_results();
        auto it = std::ranges::find_if(results, [&](auto& p) { return p.address() == address; });

        if (it != results.end()) {
            porsche = *it;
            try {
                porsche.connect();

                // Wait for BlueZ D-Bus to map UUID handles
                bool discovered = false;
                for (int i = 0; i < 30; ++i) {
                    std::this_thread::sleep_for(100ms);
                    auto services = porsche.services();
                    for (auto& s : services) {
                        if (s.uuid() == SERVICE_UUID) {
                            discovered = true;
                            break;
                        }
                    }
                    if (discovered) break;
                }

                if (!discovered) {
                    porsche.disconnect();
                    continue;
                }

                setupHandshake();
                _running = true;
                _isHardwareReady = true;

                // Background execution thread starts but sendCommand is still gated
                _txThread = std::jthread([this](std::stop_token st) { txLoop(st); });

                std::cout << "\n[HAL] Connected. Awaiting Calibration..." << std::endl;
                return true;
            } catch (...) {
                std::this_thread::sleep_for(1s);
            }
        }
    }
}

/**
 * @brief Atomic Command Latch (Latest-Wins).
 * @note ENFORCED: Commands are rejected unless isCalibrated() is true.
 */
void PorscheGt4::sendCommand(const Command& cmd) noexcept {
    if (!_isCalibrated.load()) return;

    _latestCmd.store(
        {std::clamp(cmd.steer, minRelative, maxRelative), std::clamp(cmd.throttle, -100, 100)});
    _lastCmdTime.store(getNowNs());
    _hasNewCmd.store(true);
    _txCv.notify_one();
}

/**
 * @brief High-frequency TX dispatcher.
 * Implements the non-blocking rate-gate and mechanical safety ramp.
 */
void PorscheGt4::txLoop(std::stop_token st) {
    while (!st.stop_requested()) {
        std::unique_lock lock(_txMtx);
        _txCv.wait_for(lock, std::chrono::milliseconds(_config.keepalive_ms),
                       [&] { return _hasNewCmd.load() || st.stop_requested(); });

        if (st.stop_requested()) return;

        TimestampNs now = getNowNs();
        uint64_t gate_ns = (uint64_t)_config.tx_rate_limit_ms * 1'000'000ULL;

        // Rate Gate: Check if the 15ms Bluetooth window is open
        if (now - _lastTxTimestamp < gate_ns) {
            continue;
        }

        Command target = _latestCmd.load();
        _hasNewCmd.store(false);
        lock.unlock();

        if (_calibrating.load()) continue;

        // ADAS Watchdog check
        if ((now - _lastCmdTime.load()) > (uint64_t)_config.watchdog_timeout_ms * 1'000'000ULL) {
            target.throttle = 0;
            if (_isCalibrated.load()) _status.store(HalStatus::TIMEOUT);
        } else {
            if (_isCalibrated.load()) _status.store(HalStatus::OK);
        }

        // Optional Mechanical Safety Ramp (Disabled by default per v5.0 contract)
        if (_config.max_steer_delta_per_tx > 0) {
            int32_t delta = target.steer - _lastSentSteer;
            if (delta > _config.max_steer_delta_per_tx)
                _lastSentSteer += _config.max_steer_delta_per_tx;
            else if (delta < -_config.max_steer_delta_per_tx)
                _lastSentSteer -= _config.max_steer_delta_per_tx;
            else
                _lastSentSteer = target.steer;
        } else {
            _lastSentSteer = target.steer;
        }

        try {
            if (!_isHardwareReady.load() || !porsche.is_connected()) continue;

            uint8_t vPort = _virtualDrivePort.load();
            if (vPort != 0xFF) {
                // Use Virtual Port (Unified motors) if detected
                porsche.write_command(SERVICE_UUID, CHAR_UUID,
                                      buildDriveCmd(vPort, target.throttle));
            } else {
                // Direct Dual-Motor fallback
                porsche.write_command(SERVICE_UUID, CHAR_UUID,
                                      buildDriveCmd(PORT_DRIVE_L, -target.throttle));
                porsche.write_command(SERVICE_UUID, CHAR_UUID,
                                      buildDriveCmd(PORT_DRIVE_R, target.throttle));
            }
            // Dispatch Steering Position
            porsche.write_command(SERVICE_UUID, CHAR_UUID,
                                  buildSteerCmd(hardwareCenter + _lastSentSteer));

            _lastTxTimestamp = getNowNs();

            // Profiling Log
            std::lock_guard sLock(_statsMtx);
            _pendingTx.push_back({_lastSentSteer, _lastTxTimestamp});
        } catch (...) {
            _status.store(HalStatus::DEGRADED);
        }

        std::this_thread::yield();
    }
}

/**
 * @brief Telemetry Ingestion and Profiling.
 * Updates the atomic latch and detached callback thread.
 */
void PorscheGt4::updateTelemetry(int32_t pos, uint8_t batt) {
    TimestampNs rxTime = getNowNs();
    _rawSteerPos.store(pos);
    int32_t rel = pos - hardwareCenter;

    Telemetry t{rel, rxTime, batt, true};
    _telemetryLatch.store(t);

    // Latency Matching Logic (Point #4 of Review)
    {
        std::lock_guard sLock(_statsMtx);
        for (auto it = _pendingTx.begin(); it != _pendingTx.end();) {
            // Epsilon=5 to account for LEGO mechanical gear play
            if (std::abs(it->steer_cmd - rel) <= 5 && rxTime > it->timestamp_ns) {
                float ms = (rxTime - it->timestamp_ns) / 1'000'000.0f;
                _latencySamples.push_back(ms);
                if (_latencySamples.size() > MAX_SAMPLES)
                    _latencySamples.erase(_latencySamples.begin());
                it = _pendingTx.erase(it);
            }
            // Discard stale TX packets older than 500ms
            else if ((rxTime - it->timestamp_ns) > 500'000'000ULL) {
                it = _pendingTx.erase(it);
            } else {
                ++it;
            }
        }
    }

    if (onTelemetry) {
        // Dispatch to detached thread to prevent stalling BlueZ RX loop
        std::thread([cb = onTelemetry, t]() { cb(t); }).detach();
    }
}

/**
 * @brief Essential Calibration Sequence.
 * Defines the center point and safely unlocks the sendCommand() gate.
 */
bool PorscheGt4::autoCalibrate() {
    for (int i = 0; i < 30 && !_telemetryActive.load(); i++) std::this_thread::sleep_for(100ms);
    if (!_telemetryActive.load()) return false;

    _calibrating = true;
    int32_t initialRawPos = _rawSteerPos.load();

    // 1. Left Sweep
    int32_t rawL = sweep_to_limit(-15, "LEFT");

    // 2. Gentle Return
    sendReliable(buildSteerCmd(initialRawPos, 25));
    waitForMovement(initialRawPos, 3000);

    // 3. Right Sweep
    int32_t rawR = sweep_to_limit(15, "RIGHT");

    // 4. Geometry Calculation
    hardwareCenter = (rawL + rawR) / 2;
    minRelative = (std::min(rawL, rawR) - hardwareCenter) + 4;  // 4 unit soft-margin
    maxRelative = (std::max(rawL, rawR) - hardwareCenter) - 4;

    // 5. Center and Unlock
    sendReliable(buildSteerCmd(hardwareCenter, 25));
    waitForMovement(hardwareCenter, 3000);

    _lastSentSteer = 0;
    _calibrating = false;
    _isCalibrated.store(true);  // GATE UNLOCKED

    std::cout << "[HAL] Calibrated. Zero: " << hardwareCenter << " Range: [" << minRelative << ":"
              << maxRelative << "]" << std::endl;
    return true;
}

int32_t PorscheGt4::sweep_to_limit(int8_t speed, std::string_view side) {
    // Start Motor (Open Loop)
    std::array<uint8_t, 7> buf = {0x07,
                                  HUB_ID,
                                  (uint8_t)MessageType::PORT_OUTPUT_COMMAND,
                                  PORT_STEER,
                                  (uint8_t)ExecutionFlags::IMMEDIATE,
                                  (uint8_t)PortOutputSubCommand::START_SPEED,
                                  static_cast<uint8_t>(speed)};
    sendReliable(SimpleBLE::ByteArray(reinterpret_cast<const char*>(buf.data()), 7));

    std::this_thread::sleep_for(400ms);
    int32_t last = -999, stuck = 0;

    for (int i = 0; i < 80; ++i) {
        std::this_thread::sleep_for(100ms);
        int32_t p = _rawSteerPos.load();
        if (std::abs(p - last) <= 1)
            stuck++;
        else
            stuck = 0;
        if (stuck >= 4) break;  // Physical Hard-Stop detected
        last = p;
    }

    // Stop Motor
    std::array<uint8_t, 7> stop_buf = {0x07, HUB_ID, 0x81, PORT_STEER, 0x11, 0x01, 0x00};
    sendReliable(SimpleBLE::ByteArray(reinterpret_cast<const char*>(stop_buf.data()), 7));
    std::this_thread::sleep_for(200ms);
    return _rawSteerPos.load();
}

void PorscheGt4::waitForMovement(int32_t target_abs, int timeout_ms) {
    int elapsed = 0;
    while (elapsed < timeout_ms) {
        if (std::abs(_rawSteerPos.load() - target_abs) <= 3) return;
        std::this_thread::sleep_for(100ms);
        elapsed += 100;
    }
}

void PorscheGt4::sendReliable(const SimpleBLE::ByteArray& data) {
    if (!_isHardwareReady.load()) return;
    try {
        porsche.write_command(SERVICE_UUID, CHAR_UUID, data);
    } catch (...) {
    }
    std::this_thread::sleep_for(60ms);
}

/**
 * @brief LWP3 Handshake and Telemetry Subscription.
 */
void PorscheGt4::setupHandshake() {
    porsche.notify(SERVICE_UUID, CHAR_UUID, [this](SimpleBLE::ByteArray data) {
        auto* raw = reinterpret_cast<const uint8_t*>(data.data());
        if (data.size() < 8) return;

        // Handle Steering (Port Value Single)
        if (raw[2] == (uint8_t)MessageType::PORT_VALUE_SINGLE && raw[3] == PORT_STEER) {
            _telemetryActive = true;
            int32_t val;
            std::memcpy(&val, &raw[4], sizeof(int32_t));
            updateTelemetry(val, _telemetryLatch.load().battery_level);
        }
        // Handle Drive Virtual Port Detection
        else if (raw[2] == (uint8_t)MessageType::HUB_ATTACHED_IO && raw[4] == 0x02) {
            if (raw[7] == PORT_DRIVE_L && raw[8] == PORT_DRIVE_R) _virtualDrivePort.store(raw[3]);
        }
    });

    // Request Format: Abs Position (Mode 2), Notifications ON
    porsche.write_command(
        SERVICE_UUID, CHAR_UUID,
        {0x0A, HUB_ID, (uint8_t)MessageType::PORT_INPUT_FORMAT_SETUP, PORT_STEER,
         STEER_MODE_ABS_POS, NOTIFICATIONS_ON, 0x00, 0x00, 0x00, NOTIFICATIONS_ON});
}

/**
 * @brief Protocol: Speed-based drive control.
 */
SimpleBLE::ByteArray PorscheGt4::buildDriveCmd(uint8_t port, int8_t speed) {
    std::array<uint8_t, 8> buf = {0x08,
                                  HUB_ID,
                                  (uint8_t)MessageType::PORT_OUTPUT_COMMAND,
                                  port,
                                  (uint8_t)ExecutionFlags::IMMEDIATE,
                                  (uint8_t)PortOutputSubCommand::WRITE_DIRECT_MODE_DATA,
                                  0x00,
                                  static_cast<uint8_t>(speed)};
    return SimpleBLE::ByteArray(reinterpret_cast<const char*>(buf.data()), 8);
}

/**
 * @brief Protocol: Absolute Position servo control.
 */
SimpleBLE::ByteArray PorscheGt4::buildSteerCmd(int32_t absolute_angle, uint8_t speed) {
    constexpr uint8_t PACKET_LEN = 0x0E;
    std::array<uint8_t, PACKET_LEN> buf = {PACKET_LEN,
                                           HUB_ID,
                                           (uint8_t)MessageType::PORT_OUTPUT_COMMAND,
                                           PORT_STEER,
                                           (uint8_t)ExecutionFlags::IMMEDIATE,
                                           (uint8_t)PortOutputSubCommand::GOTO_ABS_POS};
    std::memcpy(&buf[6], &absolute_angle, sizeof(int32_t));
    buf[10] = speed;
    buf[11] = MAX_MOTOR_POWER;
    buf[12] = (uint8_t)MotorEndState::HOLD;
    buf[13] = CMD_END_PACKET;
    return SimpleBLE::ByteArray(reinterpret_cast<const char*>(buf.data()), PACKET_LEN);
}

void PorscheGt4::disconnect() {
    _running = false;
    _isHardwareReady = false;
    _isCalibrated.store(false);
    _txThread.request_stop();
    _txCv.notify_all();
    if (porsche.is_connected()) {
        std::this_thread::sleep_for(100ms);  // Cool-off for BlueZ jitter
        try {
            porsche.disconnect();
        } catch (...) {
        }
    }
    _status.store(HalStatus::DISCONNECTED);
}

Telemetry PorscheGt4::getLatestTelemetry() const noexcept {
    return _telemetryLatch.load();
}

/**
 * @brief Sorting statistics for P50/P99.
 */
LatencyStats PorscheGt4::getLatencyStats() {
    std::lock_guard lock(_statsMtx);
    if (_latencySamples.empty()) return {0.0f, 0.0f, 0.0f};

    float sum = 0;
    for (float s : _latencySamples) sum += s;

    std::vector<float> sorted = _latencySamples;
    std::sort(sorted.begin(), sorted.end());

    return {sum / _latencySamples.size(), sorted[sorted.size() / 2], sorted.back()};
}

HalStatus PorscheGt4::getStatus() const noexcept {
    if (!porsche.is_connected()) return HalStatus::DISCONNECTED;
    if (!_isCalibrated.load()) return HalStatus::UNCALIBRATED;
    return _status.load();
}

// --- Public Light API (Encapsulated) ---

void PorscheGt4::setFrontLights(uint8_t brightness) noexcept {
    setLights(PORT_LIGHTS_FRONT, brightness);
}

void PorscheGt4::setRearLights(uint8_t brightness) noexcept {
    setLights(PORT_LIGHTS_REAR, brightness);
}

// --- Private Generic Implementation ---

/**
 * @brief Constructs and dispatches an LWP3 Direct Mode Write for LED ports.
 * @private
 */
void PorscheGt4::setLights(uint8_t port, uint8_t brightness) noexcept {
    if (!_isHardwareReady.load()) return;

    uint8_t val = std::min(brightness, (uint8_t)100);

    // LWP3 Packet for LED Power: [Len, HubID, MsgType, Port, Exec, SubCmd, Mode, Value]
    std::array<uint8_t, 8> buf = {
        0x08, HUB_ID, (uint8_t)MessageType::PORT_OUTPUT_COMMAND, 
        port, (uint8_t)ExecutionFlags::IMMEDIATE, 
        (uint8_t)PortOutputSubCommand::WRITE_DIRECT_MODE_DATA, 
        0x00, val
    };

    try {
        porsche.write_command(SERVICE_UUID, CHAR_UUID, 
            SimpleBLE::ByteArray(reinterpret_cast<const char*>(buf.data()), 8));
    } catch (...) {
        _status.store(HalStatus::DEGRADED);
    }
}

}  // namespace LWP3
